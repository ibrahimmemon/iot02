mod ST;


fn main(){
  
    let server_01 = ST::server_temp::get_server_temp();
    server_01.view();
    server_01.average_server_temp();
}

