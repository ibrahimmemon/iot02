pub mod servertemperature{
    use std::io;
    #[derive(Debug)]
    pub enum cpu_types{
        ARM,
        ARM64,
        X86,
        X64
    }
    pub enum gpu_types{
        AMD,
        NVIDIA
    }
    pub enum disk_types{
        HDD,
        SSD
    }
    pub struct server_temp{
         
        pub cpu_temp: i32,
        pub gpu_temp: i32,
        pub disk_temp: i32,
        pub chassis_temp: i32,
        pub cpu_type:cpu_types,
        pub gpu_type:gpu_types,
        pub disk_type:disk_types  
    }
    impl server_temp{
        pub fn new (cpu_temp:i32,gpu_temp:i32,disk_temp:i32,chassis_temp:i32,cpu_type:cpu_types,gpu_type:gpu_types,disk_type:disk_types)-> server_temp{
            server_temp{
                cpu_temp,
                gpu_temp,
                disk_temp,
                chassis_temp,
                cpu_type,
                gpu_type,
                disk_type,
            }
        }
    
        pub fn view (&self){
            println!("");
            println!("      *****************************************     ");
            println!("");
            println!("");
            println!("      * Server Temperature  Details  *     ");
    
    
            println!("Server CPU Temperature: {}",self.cpu_temp);
            println!("Server CPU Type: {}",
                      server_temp::getname_cputype(&self.cpu_type) );
            println!("----------------------------------------------");
            println!("Server GPU Temperature: {}",self.gpu_temp);
            println!("Server GPU Type: {:?}",
                     server_temp::getname_gputype(&self.gpu_type));
            println!("----------------------------------------------");
            println!("Server Disk Temperature: {}",self.disk_temp);
            println!("Server Disk Type: {}",
                      server_temp::getname_disktype(&self.disk_type));
            println!("----------------------------------------------");
            println!("Server Chassis Temperature: {}",self.chassis_temp);
       
            println!("===============================================");
            let total_temp = self.cpu_temp + self.gpu_temp + self.disk_temp + self.chassis_temp;
            let average = total_temp/4;
    
            println!("Server average Temperature :{}",average);
            
            println!("");
            println!("");
            println!("      *****************************************     ");
            
        }
        pub fn average_server_temp (&self){
            let total_temp = self.cpu_temp + self.gpu_temp + self.disk_temp + self.chassis_temp;
            let average = total_temp/4;
            
            println!("");
            println!("");
            println!("Server average Temperature :{}",average);
        }
    
    
        pub fn input_fn_integer(displayText:String)->i32{
            let mut input = String::new();
            println!("{}",displayText);
            io::stdin().read_line(&mut input);
            let input: i32 = input.trim().parse().unwrap(); // For parsing
            input
        }
    
       
        pub fn get_server_temp()->server_temp{
            let cpu_temp = server_temp::input_fn_integer(String::from("Enter CPU Temperature:"));
            let gpu_temp = server_temp::input_fn_integer(String::from("Enter GPU Temperature:"));
            let disk_temp = server_temp::input_fn_integer(String::from("Enter Disk Temperature:"));
            let chassis_temp = server_temp::input_fn_integer(String::from("Enter Chassis Temperature:"));
    
            
            let inputCPUtype = server_temp::input_fn_integer(String::from("Enter CPU Type Number Only \n (example enter 1 for ARM) \n 1.ARM, 2.ARM64, 3.X86, 4.X64 , default X64 :"));
            let cpu_type = server_temp::convert_cputype(inputCPUtype);
            
            let inputGPUtype = server_temp::input_fn_integer(String::from("Enter GPU Type Number Only \n (example enter 1 for ARM) \n 1.AMD, 2.NVIDIA,  default NVIDIA :"));
            let gpu_type = server_temp::convert_gputype(inputGPUtype);
    
            let inputDisktype = server_temp::input_fn_integer(String::from("Enter Disk Type Number Only \n (example enter 1 for AMD) \n 1.HDD, 2.SSD,  default SSD :"));
            let disk_type = server_temp::convert_disktype(inputDisktype);
    
            let server = server_temp::new(cpu_temp,
                gpu_temp,disk_temp,chassis_temp,cpu_type,gpu_type,disk_type);
            server
        }
    
        pub fn convert_cputype(typenum:i32)->cpu_types{
            if typenum == 1 {
                cpu_types::ARM
            } else if typenum == 2 {
                cpu_types::ARM64
            } else if typenum == 3 {
                cpu_types::X86
            }else if typenum == 4 {
                cpu_types::X64
            }else {
                cpu_types::X64
            }
        }
    
        pub fn convert_gputype(typenum:i32)->gpu_types{
            if typenum == 1 {
                gpu_types::AMD
            } else if typenum == 2 {
                gpu_types::NVIDIA
            }else {
                gpu_types::NVIDIA
            }
        }
    
        pub fn convert_disktype(typenum:i32)->disk_types{
            if typenum == 1 {
                disk_types::HDD
            } else if typenum == 2 {
                disk_types::SSD
            }else {
                disk_types::SSD
            }
        }
    
    
    
    
        pub fn getname_cputype(typenum:&cpu_types)->String{
            match typenum{
                 
                cpu_types::ARM => String::from("ARM"),
                cpu_types::ARM64 => String::from("ARM64"),
                cpu_types::X86 =>  String::from("X86"),
                cpu_types::X64 =>  String::from("X64"),
                 
            } 
        }
    
        pub fn getname_gputype(typenum:&gpu_types)->String{
            match typenum{
                gpu_types::AMD=>String::from("AMD"),
                gpu_types::NVIDIA=>String::from("NVIDIA"),
            }
            
        }
    
        pub fn getname_disktype(typenum:&disk_types)->String{
            match typenum{
                disk_types::HDD=>String::from("HDD"),
                disk_types::SSD=>String::from("SSD"),
            } 
        }
    
    }
    
    
    
    

}